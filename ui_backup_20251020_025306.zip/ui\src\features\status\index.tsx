export { default } from './view/StatusPage';
