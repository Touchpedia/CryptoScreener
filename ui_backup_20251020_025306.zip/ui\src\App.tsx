import StatusPage from './features/status';
export default function App() {
  return (
    <div style={{padding:16}}>
      <div style={{marginBottom:12, fontSize:18}}>APP MOUNT ?</div>
      <StatusPage />
    </div>
  );
}
